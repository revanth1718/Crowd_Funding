# Build and Deploy a Web3 Crowdfunding Platform (Kickstarter) As Your First Blockchain Application
![Crowdfunding](https://i.ibb.co/k6pj0Qt/htum-6.png)

### [🌟 Become a top 1% Next.js 13 developer in only one course](https://jsmastery.pro/next13)
### [🚀 Land your dream programming job in 6 months](https://jsmastery.pro/masterclass)

### Launch your development career with project-based coaching on [JS Mastery Pro](https://www.jsmastery.pro).
